const KittyCoreMock = artifacts.require("KittyCoreMock");
const ZombieOwnership = artifacts.require("ZombieOwnership");

module.exports = async function (deployer) {
  await deployer.deploy(KittyCoreMock);
  const kitty = await KittyCoreMock.deployed();

  await deployer.deploy(ZombieOwnership);
  const zombies = await ZombieOwnership.deployed();

  if (zombies.setKittyContractAddress) {
    await zombies.setKittyContractAddress(kitty.address);
  }
  console.log("KittyCoreMock:", kitty.address);
  console.log("ZombieOwnership:", zombies.address);
};
