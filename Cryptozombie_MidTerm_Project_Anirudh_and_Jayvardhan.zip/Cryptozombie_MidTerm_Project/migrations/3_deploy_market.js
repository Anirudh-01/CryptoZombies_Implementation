const ZombieMarket = artifacts.require("ZombieMarket");

module.exports = async function (deployer, network, accounts) {
  const FEE_BPS = 250;
  const FEE_WALLET = accounts[0];
  await deployer.deploy(ZombieMarket, FEE_BPS, FEE_WALLET);
};
