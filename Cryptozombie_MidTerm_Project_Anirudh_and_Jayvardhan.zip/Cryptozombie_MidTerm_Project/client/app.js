/* global Web3 */
const ZOMBIE_JSON_PATH = "/build/contracts/ZombieOwnership.json";
const KITTY_JSON_PATH  = "/build/contracts/KittyCoreMock.json";

let web3, accounts, defaultAccount, networkId;
let zombie, kitty;

function robohashUrl(seed, { kitty = false } = {}) {
  const set = kitty ? 'set4' : 'set2';
  return `https://robohash.org/${encodeURIComponent(String(seed))}.png?set=${set}&bgset=bg2&size=300x300`;
}

function robohashImgTag(seed, isKitty) {
  const url = robohashUrl(seed, { kitty: isKitty });
  return `<img src="${url}" alt="avatar"
              style="width:100%;height:100%;display:block"
              onerror="this.parentNode.innerHTML='<div style=&quot;opacity:.6&quot;>avatar</div>'">`;
}



const $ = (id) => document.getElementById(id);

async function connect() {
  if (!window.ethereum) {
    $('status').textContent = 'MetaMask not found';
    return;
  }
  web3 = new Web3(window.ethereum);
  await window.ethereum.request({ method: 'eth_requestAccounts' });
  accounts = await web3.eth.getAccounts();
  defaultAccount = accounts[0];
  networkId = await web3.eth.net.getId();
  $('account').textContent = defaultAccount;
  $('network').textContent = networkId;
  $('status').textContent = 'Connected';
  await initContracts();

  if (!window.ethereum._czPatched) {
    window.ethereum._czPatched = true;
    window.ethereum.on('accountsChanged', async (accs) => {
      accounts = accs || await web3.eth.getAccounts();
      defaultAccount = accounts[0];
      $('account').textContent = defaultAccount || '—';
      await refresh();
    });
    window.ethereum.on('chainChanged', () => location.reload());
  }
}

async function initContracts() {
  const [zombieJson, kittyJson] = await Promise.all([
    (await fetch(ZOMBIE_JSON_PATH)).json(),
    (await fetch(KITTY_JSON_PATH)).json()
  ]);
  // pick address robustly
  const pick = (json, id) => json.networks?.[id]?.address || Object.values(json.networks||{})[0]?.address;
  const zAddress = pick(zombieJson, networkId);
  const kAddress = pick(kittyJson,  networkId);
  if (!zAddress || !kAddress) { alert("Contracts not found. Migrate on this network."); return; }
  zombie = new web3.eth.Contract(zombieJson.abi, zAddress);
  kitty  = new web3.eth.Contract(kittyJson.abi,  kAddress);
  console.log("Zombie @", zAddress); console.log("Kitty @", kAddress);
}

function zombieCard(id, z) {
  const card = document.createElement('div');
  card.className = 'zcard';

  const imgBox = document.createElement('div');
  imgBox.className = 'zimg';

  const title = document.createElement('h3');
  title.textContent = `#${id} — ${z.name || `Kitty${id}`}`;

  const isKitty = Number(String(z.dna).slice(-2)) === 99; // kitty-derived flag
  const meta = document.createElement('p');
  const kittyBadge = isKitty ? ' 🐱' : '';
  meta.innerHTML = `DNA: ${z.dna}${kittyBadge}<br/>Level: ${z.level} | Wins: ${z.winCount} | Losses: ${z.lossCount}`;

  imgBox.innerHTML = robohashImgTag(z.dna, isKitty);

  card.appendChild(imgBox);
  card.appendChild(title);
  card.appendChild(meta);
  return card;
}



async function refreshListFor(addr) {
  const list = $('zombieList');
  list.innerHTML = '';
  if (!zombie) return;
  const ids = await zombie.methods.getZombiesByOwner(addr).call();
  for (let id of ids) {
    const z = await zombie.methods.zombies(id).call();
    list.appendChild(zombieCard(id, z));
  }
}

async function refresh() {
  if (!defaultAccount) return;
  await refreshListFor(defaultAccount);
}

async function create() {
  if (!zombie) { await connect(); if (!zombie) return; }
  const name = $('zombieName').value || 'Nameless';
  await zombie.methods.createRandomZombie(name).send({ from: defaultAccount });
  await refresh();
}

async function feed() {
  const zid = $('zombieId').value;
  const kid = $('kittyId').value || 1;
  await zombie.methods.feedOnKitty(zid, kid).send({ from: defaultAccount });
  await refresh();
}

async function levelUp() {
  const zid = $('levelZombieId').value;
  await zombie.methods.levelUp(zid).send({ from: defaultAccount, value: "0" });
  await refresh();
}

async function rename() {
  const zid = $('renameZombieId').value;
  const newName = $('newName').value || 'Renamed';
  await zombie.methods.changeName(zid, newName).send({ from: defaultAccount });
  await refresh();
}

async function transfer() {
  const zid = $('transferZombieId').value;
  const to = $('toAddress').value;
  await zombie.methods.transfer(to, zid).send({ from: defaultAccount });
  await refresh();
}

async function viewAddress() {
  const addr = $('viewAddr').value.trim();
  if (!addr) return;
  await refreshListFor(addr);
}

window.addEventListener('load', () => {
  $('connectBtn').onclick = connect;
  $('refreshBtn').onclick = refresh;
  $('createBtn').onclick = create;
  $('feedBtn').onclick = feed;
  $('levelBtn').onclick = levelUp;
  $('renameBtn').onclick = rename;
  $('transferBtn').onclick = transfer;
  $('viewBtn').onclick = viewAddress;
});
